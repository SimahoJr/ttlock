
-- TTLock.lua
-- Standalone Solar2D simulator mock.
-- No require() calls and no native BLE dependency.

local TTLock = {}
TTLock.__index = TTLock

local json = json
local timer = timer
local system = system

local DEFAULT_AES_KEY = string.char(
    0x98, 0x76, 0x23, 0xE8,
    0xA9, 0x23, 0xA1, 0xBB,
    0x3D, 0x9E, 0x7D, 0x03,
    0x78, 0x12, 0x45, 0x88
)

local DEFAULT_DEVICE_ID = "15:6E:16:FD:32:A6"

local function later(callback, delay)
    if timer and timer.performWithDelay then
        timer.performWithDelay(delay or 50, callback)
    elseif callback then
        callback()
    end
end

local function toHex(data)
    if type(data) ~= "string" then
        return ""
    end

    return (data:gsub(".", function(c)
        return string.format("%02X", string.byte(c))
    end))
end

local function fromHex(hex)
    if type(hex) ~= "string" then
        return nil
    end

    return (hex:gsub("%x%x", function(pair)
        return string.char(tonumber(pair, 16))
    end))
end

local function unpackInt32(data, position)
    if type(data) ~= "string" or #data < position + 3 then
        return 0
    end

    local a, b, c, d = data:byte(position, position + 3)
    return a * 16777216 + b * 65536 + c * 256 + d
end

function TTLock.new()
    local self = setmetatable({}, TTLock)

    self.mac_address = DEFAULT_DEVICE_ID
    self.deviceId = DEFAULT_DEVICE_ID
    self.address = ""
    self.protocol_type = 5
    self.protocol_version = 3
    self.scene = 1
    self.aes_key = DEFAULT_AES_KEY
    self.admin_ps = 0
    self.unlock_key = 0
    self.admin_passcode = ""

    self.battery = 100
    self.locked_status = 1
    self.auto_lock_time = 0

    self.connected = false
    self.paired = false
    self.locked = true
    self.passcodes = {}
    self.ic_cards = {}
    self.fingerprints = {}
    self.passage_modes = {}
    self.operation_log = {}
    self.lock_sound_enabled = true

    self._next_id = 1

    return self
end

function TTLock:load()
    if not system or not system.pathForFile or not json then
        return false
    end

    local path = system.pathForFile(
        "ttlock.json",
        system.DocumentsDirectory
    )

    local file = io.open(path, "r")
    if not file then
        return false
    end

    local contents = file:read("*a")
    file:close()

    local ok, decoded = pcall(json.decode, contents)

    if not ok or type(decoded) ~= "table" then
        print("[TTLock Mock] Invalid configuration file.")
        return false
    end

    self.address = decoded.address or ""
    self.protocol_type = decoded.protocol_type or 5
    self.protocol_version = decoded.protocol_version or 3
    self.scene = decoded.scene or 1
    self.admin_ps = decoded.admin_ps or 0
    self.unlock_key = decoded.unlock_key or 0
    self.admin_passcode = decoded.admin_passcode or ""

    if type(decoded.aes_key) == "string" then
        self.aes_key = fromHex(decoded.aes_key) or DEFAULT_AES_KEY
    end

    print("[TTLock Mock] Configuration loaded.")
    return true
end

function TTLock:save()
    if not system or not system.pathForFile or not json then
        return false
    end

    local path = system.pathForFile(
        "ttlock.json",
        system.DocumentsDirectory
    )

    local file = io.open(path, "w")
    if not file then
        print("[TTLock Mock] Could not save configuration.")
        return false
    end

    local data = {
        address = self.address,
        protocol_type = self.protocol_type,
        protocol_version = self.protocol_version,
        scene = self.scene,
        aes_key = toHex(self.aes_key),
        admin_ps = self.admin_ps,
        unlock_key = self.unlock_key,
        admin_passcode = self.admin_passcode
    }

    file:write(json.encode(data))
    file:close()

    print("[TTLock Mock] Configuration saved.")
    return true
end

function TTLock:clear(callback)
    local success = false

    if system and system.pathForFile then
        local path = system.pathForFile(
            "ttlock.json",
            system.DocumentsDirectory
        )

        success = os.remove(path) and true or false
    end

    self.address = ""
    self.protocol_type = 5
    self.protocol_version = 3
    self.scene = 1
    self.aes_key = DEFAULT_AES_KEY
    self.admin_ps = 0
    self.unlock_key = 0
    self.admin_passcode = ""

    self.paired = false

    if callback then
        callback(success)
    end

    return success
end

function TTLock:connect(callback)
    later(function()
        self.connected = true

        if callback then
            callback(true)
        end
    end)
end

function TTLock:disconnect()
    self.connected = false
end

function TTLock:withAuth(callback, action)
    self:connect(function(connected)
        if not connected then
            if callback then
                callback({
                    status = 0,
                    error = "Connection failed"
                })
            end
            return
        end

        if action then
            action(self.admin_ps)
        end
    end)
end

function TTLock:withAuthOld(callback, action)
    self:withAuth(callback, action)
end

function TTLock:pair(callback)
    later(function()
        self.connected = true
        self.paired = true

        if self.admin_ps == 0 then
            self.admin_ps = math.random(100000, 999999)
        end

        if self.unlock_key == 0 then
            self.unlock_key = math.random(100000, 999999)
        end

        self.aes_key = DEFAULT_AES_KEY
        self:save()

        local credentials = {
            aes_key = toHex(self.aes_key),
            admin_ps = self.admin_ps,
            unlock_key = self.unlock_key
        }

        print("[TTLock Mock] Pairing simulated.")

        if callback then
            callback(true, credentials)
        end
    end)
end

function TTLock:unlock(callback)
    self:withAuth(callback, function()
        self.locked = false
        self.locked_status = 0
        self.battery = math.max(0, self.battery)

        table.insert(self.operation_log, {
            id = self._next_id,
            operation = "unlock"
        })
        self._next_id = self._next_id + 1

        if callback then
            callback({
                status = 1,
                data = string.char(self.battery),
                message = "Unlock simulated"
            })
        end
    end)
end

function TTLock:lock(callback)
    self:withAuth(callback, function()
        self.locked = true
        self.locked_status = 1

        table.insert(self.operation_log, {
            id = self._next_id,
            operation = "lock"
        })
        self._next_id = self._next_id + 1

        if callback then
            callback({
                status = 1,
                data = string.char(self.battery),
                message = "Lock simulated"
            })
        end
    end)
end

function TTLock:reset(callback)
    self.locked = true
    self.locked_status = 1
    self.paired = false
    self.admin_ps = 0
    self.unlock_key = 0
    self.admin_passcode = ""
    self.aes_key = DEFAULT_AES_KEY
    self.passcodes = {}
    self.ic_cards = {}
    self.fingerprints = {}
    self.passage_modes = {}

    self:save()

    if callback then
        callback({ status = 1, message = "Reset simulated" })
    end
end

-- ============================================================
-- DEVICE STATUS / TIME / DEVICE INFO
-- ============================================================

function TTLock:get_locked_status(callback)
    if callback then
        callback(self.locked and 1 or 0)
    end
end

function TTLock:get_device_features(callback)
    local features = {
        "passcodes",
        "ic_cards",
        "fingerprints",
        "auto_lock",
        "passage_mode",
        "lock_sound"
    }

    if callback then
        callback(features)
    end
end

function TTLock:get_device_info(callback)
    local response = {
        status = 1,
        data = {
            deviceId = self.deviceId,
            address = self.address,
            protocol_type = self.protocol_type,
            protocol_version = self.protocol_version,
            battery = self.battery,
            locked = self.locked
        }
    }

    if callback then
        callback(response)
    end
end

function TTLock:calibrate_time(callback)
    if callback then
        callback({
            status = 1,
            message = "Time calibration simulated"
        })
    end
end

function TTLock:get_admin_code(callback)
    if callback then
        callback({
            status = 1,
            passcode = self.admin_passcode
        })
    end
end

function TTLock:set_admin_code(new_passcode, callback)
    if not new_passcode then
        new_passcode = tostring(math.random(1000000, 9999999))
    end

    self.admin_passcode = tostring(new_passcode)
    self:save()

    if callback then
        callback({
            status = 1,
            passcode = self.admin_passcode
        })
    end
end

-- ============================================================
-- AUTO-LOCK
-- ============================================================

function TTLock:get_autolock_time(callback)
    if callback then
        callback(self.auto_lock_time)
    end
end

function TTLock:set_autolock_time(seconds, callback)
    seconds = tonumber(seconds)

    if not seconds or seconds < 0 then
        if callback then
            callback({
                status = 0,
                error = "Invalid auto-lock time"
            })
        end
        return
    end

    self.auto_lock_time = seconds

    if callback then
        callback({
            status = 1,
            auto_lock_time = self.auto_lock_time
        })
    end
end

-- ============================================================
-- LOCK SOUND
-- ============================================================

function TTLock:get_lock_sound(callback)
    if callback then
        callback({
            status = 1,
            enabled = self.lock_sound_enabled
        })
    end
end

function TTLock:set_lock_sound(enabled, callback)
    self.lock_sound_enabled = not not enabled

    if callback then
        callback({
            status = 1,
            enabled = self.lock_sound_enabled
        })
    end
end

-- ============================================================
-- PASSAGE MODE
-- ============================================================

function TTLock:get_passage_mode(callback)
    local result = {}

    for i, mode in ipairs(self.passage_modes) do
        result[i] = mode
    end

    if callback then
        callback(result)
    end
end

function TTLock:add_passage_mode(
    pm_type,
    week_or_day,
    month,
    start_hour,
    end_hour,
    callback
)
    local mode = {
        id = self._next_id,
        pm_type = pm_type,
        week_or_day = week_or_day,
        month = month,
        start_hour = start_hour,
        end_hour = end_hour
    }

    self._next_id = self._next_id + 1
    table.insert(self.passage_modes, mode)

    if callback then
        callback({
            status = 1,
            mode = mode
        })
    end
end

function TTLock:delete_passage_mode(
    pm_type,
    week_or_day,
    month,
    start_hour,
    end_hour,
    callback
)
    for i = #self.passage_modes, 1, -1 do
        local mode = self.passage_modes[i]

        if mode.pm_type == pm_type
            and mode.week_or_day == week_or_day
            and mode.month == month
            and mode.start_hour == start_hour
            and mode.end_hour == end_hour then
            table.remove(self.passage_modes, i)
        end
    end

    if callback then
        callback({ status = 1 })
    end
end

function TTLock:clear_passage_mode(callback)
    self.passage_modes = {}

    if callback then
        callback({ status = 1 })
    end
end

-- ============================================================
-- PASSCODES
-- ============================================================

function TTLock:get_passcodes(callback)
    local result = {}

    for i, item in ipairs(self.passcodes) do
        result[i] = item
    end

    if callback then
        callback(result)
    end
end

function TTLock:add_passcode(
    pwd_type,
    passcode,
    start_date,
    end_date,
    callback
)
    passcode = passcode or tostring(math.random(100000, 999999))

    local item = {
        id = self._next_id,
        pwd_type = pwd_type,
        passcode = tostring(passcode),
        start_date = start_date,
        end_date = end_date
    }

    self._next_id = self._next_id + 1
    table.insert(self.passcodes, item)

    if callback then
        callback({
            status = 1,
            item = item
        })
    end
end

function TTLock:update_passcode(
    old_passcode,
    new_passcode,
    pwd_type,
    start_date,
    end_date,
    callback
)
    for _, item in ipairs(self.passcodes) do
        if item.passcode == tostring(old_passcode) then
            item.passcode = tostring(new_passcode)
            item.pwd_type = pwd_type
            item.start_date = start_date
            item.end_date = end_date

            if callback then
                callback({ status = 1, item = item })
            end
            return
        end
    end

    if callback then
        callback({
            status = 0,
            error = "Passcode not found"
        })
    end
end

function TTLock:delete_passcode(passcode, pwd_type, callback)
    for i = #self.passcodes, 1, -1 do
        if self.passcodes[i].passcode == tostring(passcode) then
            table.remove(self.passcodes, i)
        end
    end

    if callback then
        callback({ status = 1 })
    end
end

function TTLock:clear_passcodes(callback)
    self.passcodes = {}

    if callback then
        callback({ status = 1 })
    end
end

-- ============================================================
-- IC CARDS
-- ============================================================

function TTLock:get_ic_cards(callback)
    local result = {}

    for i, item in ipairs(self.ic_cards) do
        result[i] = item
    end

    if callback then
        callback(result)
    end
end

function TTLock:add_ic_card(start_date, end_date, callback)
    local item = {
        id = self._next_id,
        card_number = tostring(self._next_id),
        start_date = start_date,
        end_date = end_date
    }

    self._next_id = self._next_id + 1
    table.insert(self.ic_cards, item)

    if callback then
        callback({
            status = 1,
            item = item
        })
    end
end

function TTLock:update_ic_card(card_number, start_date, end_date, callback)
    for _, item in ipairs(self.ic_cards) do
        if item.card_number == tostring(card_number) then
            item.start_date = start_date
            item.end_date = end_date

            if callback then
                callback({ status = 1, item = item })
            end
            return
        end
    end

    if callback then
        callback({
            status = 0,
            error = "IC card not found"
        })
    end
end

function TTLock:delete_ic_card(card_number, callback)
    for i = #self.ic_cards, 1, -1 do
        if self.ic_cards[i].card_number == tostring(card_number) then
            table.remove(self.ic_cards, i)
        end
    end

    if callback then
        callback({ status = 1 })
    end
end

function TTLock:clear_ic_cards(callback)
    self.ic_cards = {}

    if callback then
        callback({ status = 1 })
    end
end

-- ============================================================
-- FINGERPRINTS
-- ============================================================

function TTLock:get_fingerprints(callback)
    local result = {}

    for i, item in ipairs(self.fingerprints) do
        result[i] = item
    end

    if callback then
        callback(result)
    end
end

function TTLock:add_fingerprint(start_date, end_date, callback)
    local item = {
        id = self._next_id,
        fingerprint_number = tostring(self._next_id),
        start_date = start_date,
        end_date = end_date
    }

    self._next_id = self._next_id + 1
    table.insert(self.fingerprints, item)

    if callback then
        callback({
            status = 1,
            item = item
        })
    end
end

function TTLock:update_fingerprint(
    fp_number,
    start_date,
    end_date,
    callback
)
    for _, item in ipairs(self.fingerprints) do
        if item.fingerprint_number == tostring(fp_number) then
            item.start_date = start_date
            item.end_date = end_date

            if callback then
                callback({ status = 1, item = item })
            end
            return
        end
    end

    if callback then
        callback({
            status = 0,
            error = "Fingerprint not found"
        })
    end
end

function TTLock:delete_fingerprint(fp_number, callback)
    for i = #self.fingerprints, 1, -1 do
        if self.fingerprints[i].fingerprint_number == tostring(fp_number) then
            table.remove(self.fingerprints, i)
        end
    end

    if callback then
        callback({ status = 1 })
    end
end

function TTLock:clear_fingerprints(callback)
    self.fingerprints = {}

    if callback then
        callback({ status = 1 })
    end
end


-- ============================================================
-- OPERATION LOG
-- ============================================================

function TTLock:get_operation_log(callback)
    local result = {}

    for i, entry in ipairs(self.operation_log) do
        result[i] = entry
    end

    if callback then
        callback(result)
    end
end

-- ============================================================
-- SIMULATOR HELPERS
-- These methods are for local testing only.
-- ============================================================

function TTLock:is_connected()
    return self.connected
end

function TTLock:is_paired()
    return self.paired
end

function TTLock:is_locked()
    return self.locked
end

function TTLock:get_battery()
    return self.battery
end

function TTLock:set_battery(level)
    level = tonumber(level)

    if not level then
        return false
    end

    self.battery = math.max(0, math.min(100, level))
    return true
end

function TTLock:set_device_id(id)
    if type(id) ~= "string" or id == "" then
        return false
    end

    self.deviceId = id
    self.mac_address = id
    return true
end

function TTLock:simulate_disconnect(callback)
    self.connected = false

    if callback then
        callback({
            status = 1,
            message = "Disconnection simulated"
        })
    end
end

function TTLock:simulate_operation(operation, callback)
    if operation == "lock" then
        return self:lock(callback)
    elseif operation == "unlock" then
        return self:unlock(callback)
    elseif operation == "reset" then
        return self:reset(callback)
    end

    if callback then
        callback({
            status = 0,
            error = "Unknown operation: " .. tostring(operation)
        })
    end
end

function TTLock:clear_operation_log(callback)
    self.operation_log = {}

    if callback then
        callback({ status = 1 })
    end
end

function TTLock:reset_mock_state(callback)
    self.connected = false
    self.paired = false
    self.locked = true
    self.locked_status = 1
    self.battery = 100
    self.auto_lock_time = 0
    self.lock_sound_enabled = true

    self.passcodes = {}
    self.ic_cards = {}
    self.fingerprints = {}
    self.passage_modes = {}
    self.operation_log = {}

    self._next_id = 1

    self:clear(function()
        if callback then
            callback({
                status = 1,
                message = "Mock state reset"
            })
        end
    end)
end

-- ============================================================
-- END OF TTLock MOCK
-- ============================================================

return TTLock
