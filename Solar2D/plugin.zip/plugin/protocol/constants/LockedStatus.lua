return {
  UNKNOWN = -1,
  LOCKED = 0,
  UNLOCKED = 1,
}